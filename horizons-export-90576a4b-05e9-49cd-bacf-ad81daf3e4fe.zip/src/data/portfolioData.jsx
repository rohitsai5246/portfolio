
import React from 'react';
import { Layout, Code, Smartphone, Database, Search, BarChart, Calendar, MapPin, Mail, Phone, Briefcase, GraduationCap, Brain, MessageSquare, Users, Zap, Lightbulb, Target, Clock, Users2, Smile, Award, Settings, Bot, Palette, FileText, Lock, Mic, Gamepad, Eye, PenTool, GitBranch, Cloud } from 'lucide-react';

export const portfolioData = {
  personalInfo: {
    name: "Kamepalli Rohit Sai",
    title: "AI and ML Engineer",
    greeting: "Hello, I'm",
    introduction: "A passionate AI and ML Engineer seeking exciting opportunities to leverage my skills in developing innovative solutions. I'm eager to contribute to impactful projects and grow within a dynamic team.",
    profileImage: "https://storage.googleapis.com/hostinger-horizons-assets-prod/90576a4b-05e9-49cd-bacf-ad81daf3e4fe/72e8ec2c195f7183dbe067cdf4fb0d60.jpg",
    cvLink: "https://storage.googleapis.com/hostinger-horizons-assets-prod/90576a4b-05e9-49cd-bacf-ad81daf3e4fe/273050d74e6cc8e0759d3934d5697b00.jpg", 
  },
  contactInfo: {
    email: "rohitsaikamepalli@gmail.com",
    phone: "+91 8008160135",
    location: "Guntur, India",
    address: "Guntur, Andhra Pradesh, India",
    whatsapp: "+918008160135"
  },
  socialLinks: [
    { name: "GitHub", url: "https://github.com/rohitsai5246", icon: "GitHub" },
    { name: "LinkedIn", url: "https://www.linkedin.com/in/kamepalli-rohit-sai-b17774292/", icon: "Linkedin" },
  ],
  about: {
    title: "About Me",
    subtitle: "Driven AI/ML Engineer Ready for New Challenges",
    bio: [
      "I am a dedicated and forward-thinking AI and ML Engineer with a strong foundation in developing intelligent systems and a keen interest in leveraging data to solve complex problems. Currently pursuing my Bachelor of Technology, I am actively seeking job opportunities where I can apply my skills in machine learning, natural language processing, computer vision, and data analytics.",
      "My experience includes an internship at AICTE, focusing on AI and ML, and numerous projects that showcase my ability to build end-to-end solutions. I am a proficient prompt engineer, adept at utilizing AI tools optimally, and I thrive in collaborative environments, bringing both technical expertise and strong soft skills to the table."
    ],
    details: [
      { icon: <Calendar className="h-5 w-5" />, label: 'Date of Birth', value: 'August 2, 2006' },
      { icon: <MapPin className="h-5 w-5" />, label: 'Location', value: 'Guntur, India' },
      { icon: <Mail className="h-5 w-5" />, label: 'Email', value: 'rohitsaikamepalli@gmail.com' },
      { icon: <Phone className="h-5 w-5" />, label: 'Phone', value: '+91 8008160135' },
    ],
    aboutImage: "https://storage.googleapis.com/hostinger-horizons-assets-prod/90576a4b-05e9-49cd-bacf-ad81daf3e4fe/72e8ec2c195f7183dbe067cdf4fb0d60.jpg"
  },
  resume: {
    title: "My Resume",
    subtitle: "Education & Experience",
    education: [
      {
        degree: 'Bachelor of Technology',
        institution: 'Vasireddy Venkatadri Institute of Technology',
        period: 'Expected 2027',
        description: 'Currently pursuing a B.Tech degree with a focus on Computer Science and Engineering, specializing in AI and Machine Learning concepts and applications.',
        icon: <GraduationCap className="h-4 w-4" />
      }
    ],
    experience: [
      {
        position: 'AI and ML Virtual Intern',
        company: 'AICTE',
        period: 'March 2025 - April 2025 (as per resume, assuming future date)',
        description: 'Completed a 4-week virtual internship focusing on Artificial Intelligence, Machine Learning, Deep Learning, and Generative AI. Gained hands-on experience with model development, data analytics, and real-world AI applications. Received industry-recognized certifications.',
        icon: <Briefcase className="h-4 w-4" />
      }
    ]
  },
  services: {
    title: "My Services",
    subtitle: "How I Can Help You Achieve Your Goals",
    items: [
      {
        icon: <Layout className="h-10 w-10" />,
        title: 'Front-End Development',
        description: 'Crafting responsive and user-friendly interfaces for web applications.'
      },
      {
        icon: <Database className="h-10 w-10" />,
        title: 'Database Management',
        description: 'Designing and managing efficient database solutions for various applications.'
      },
      {
        icon: <MessageSquare className="h-10 w-10" />,
        title: 'Natural Language Processing (NLP)',
        description: 'Developing systems that understand, interpret, and generate human language.'
      },
      {
        icon: <Eye className="h-10 w-10" />,
        title: 'Computer Vision',
        description: 'Building algorithms to enable computers to interpret and understand visual information from images and videos.'
      },
      {
        icon: <Brain className="h-10 w-10" />,
        title: 'Machine Learning Solutions',
        description: 'Creating custom ML models to extract insights, make predictions, and automate tasks.'
      },
      {
        icon: <BarChart className="h-10 w-10" />,
        title: 'Data Analytics & Visualization',
        description: 'Analyzing complex datasets and presenting findings through clear and impactful visualizations.'
      },
      {
        icon: <Bot className="h-10 w-10" />,
        title: 'AI Application Development',
        description: 'Building intelligent applications that integrate AI/ML capabilities to solve specific problems.'
      },
      {
        icon: <Zap className="h-10 w-10" />,
        title: 'Predictive Modeling',
        description: 'Developing models to forecast future outcomes and trends based on historical data.'
      },
      {
        icon: <Settings className="h-10 w-10" />,
        title: 'Optimal AI Tool Utilization',
        description: 'Leveraging a wide range of AI tools and platforms efficiently to achieve project objectives.'
      },
      {
        icon: <PenTool className="h-10 w-10" />,
        title: 'Prompt Engineering',
        description: 'Designing and refining prompts to elicit the best possible responses from AI models, especially LLMs.'
      }
    ]
  },
  skills: {
    title: "My Skills",
    subtitle: "Technical Proficiencies & Soft Strengths",
    technicalSkills: [
      { name: 'Python', percentage: 90 },
      { name: 'Machine Learning', percentage: 85 },
      { name: 'Deep Learning (TensorFlow/PyTorch)', percentage: 80 },
      { name: 'Data Analysis (Pandas, NumPy)', percentage: 85 },
      { name: 'SQL', percentage: 75 },
      { name: 'Cloud Platforms (AWS/Azure/GCP)', percentage: 70 },
      { name: 'Java', percentage: 70 },
      { name: 'C', percentage: 70 },
      { name: 'Data Structures & Algorithms (DSA)', percentage: 80 },
      { name: 'Natural Language Processing (NLP)', percentage: 75 },
      { name: 'Front-End Development (HTML, CSS, JS)', percentage: 70 },
      { name: 'Google Cloud Skill Boost', percentage: 80 },
    ],
    softSkills: [
      { name: 'Communication', description: 'Ability to clearly convey ideas, both verbally and in writing.', icon: <MessageSquare className="h-5 w-5" /> },
      { name: 'Teamwork', description: 'Collaborative mindset; working effectively with others to reach a common goal.', icon: <Users className="h-5 w-5" /> },
      { name: 'Problem-Solving', description: 'Analytical thinking to identify issues and find efficient solutions.', icon: <Lightbulb className="h-5 w-5" /> },
      { name: 'Time Management', description: 'Prioritizing tasks and meeting deadlines without compromising quality.', icon: <Clock className="h-5 w-5" /> },
      { name: 'Adaptability', description: 'Comfortably adjusting to new tools, challenges, or team dynamics.', icon: <GitBranch className="h-5 w-5" /> },
      { name: 'Critical Thinking', description: 'Evaluating information logically to make informed decisions.', icon: <Brain className="h-5 w-5" /> },
      { name: 'Leadership', description: 'Taking initiative, motivating team members, or guiding projects toward success.', icon: <Award className="h-5 w-5" /> },
      { name: 'Emotional Intelligence', description: 'Understanding and managing your own emotions and those of others.', icon: <Smile className="h-5 w-5" /> },
      { name: 'Creativity', description: 'Bringing fresh ideas, innovation, or unique approaches to problems.', icon: <Palette className="h-5 w-5" /> },
      { name: 'Work Ethic', description: 'Dependable, committed, and consistently giving your best effort.', icon: <Target className="h-5 w-5" /> },
    ],
    tools: ['Python', 'TensorFlow', 'PyTorch', 'Scikit-learn', 'Pandas', 'NumPy', 'Jupyter Notebooks', 'Git', 'Docker', 'Google Cloud Platform', 'SQL Databases', 'HTML/CSS/JS', 'VS Code', 'Flask']
  },
  projects: {
    title: "My Projects",
    subtitle: "A Showcase of My Work and Passion",
    items: [
      {
        id: 'brick-breaker-game',
        title: 'Brick Breaker Game',
        category: 'Game Development',
        shortDescription: 'A classic Brick Breaker game developed using Python and Pygame library.',
        detailedDescription: "This project is a Python-based implementation of the classic Brick Breaker arcade game. It utilizes the Pygame library for graphics, event handling, and game logic. Features include multiple levels, scoring, power-ups (though not explicitly mentioned, can be a point of discussion), and collision detection. The game demonstrates proficiency in Python programming, object-oriented principles, and game development fundamentals.",
        technologies: ['Python', 'Pygame'],
        githubLink: 'https://github.com/rohitsai5246/Brick-Breaker-Game',
        image: 'Classic brick breaker game interface with paddle and bricks',
        imagePlaceholder: "https://images.unsplash.com/photo-1580238429601-79de8589f73f"
      },
      {
        id: 'ai-powered-chatbot',
        title: 'AI Powered Chatbot',
        category: 'Conversational AI',
        shortDescription: 'An intelligent chatbot capable of understanding queries and providing relevant responses.',
        detailedDescription: "Developed an AI-powered chatbot designed to engage in natural conversations and assist users with information or tasks. This project involved using NLP techniques for intent recognition and entity extraction, and potentially a framework like Rasa or Dialogflow, or custom-built logic. The chatbot can be trained on specific domains to provide specialized assistance. Key aspects include dialogue management, response generation, and integration capabilities.",
        technologies: ['Python', 'NLTK/spaCy', 'Machine Learning', 'Flask (for API)'],
        githubLink: 'https://github.com/rohitsai5246/AI-Powered-Chatbot',
        image: 'Chatbot interface showing a conversation flow',
        imagePlaceholder: "https://images.unsplash.com/photo-1589349595066-509c48197389"
      },
      {
        id: 'facial-recognition-system',
        title: 'Facial Recognition System',
        category: 'Computer Vision',
        shortDescription: 'A system to detect and recognize faces from images or video streams.',
        detailedDescription: "This project implements a facial recognition system using computer vision libraries like OpenCV and deep learning models. It can detect faces in real-time or from static images, and then identify individuals based on a pre-trained database of faces. The system involves face detection, feature extraction (e.g., using embeddings like FaceNet or dlib), and classification. It highlights skills in image processing and applied machine learning.",
        technologies: ['Python', 'OpenCV', 'dlib/FaceNet', 'Deep Learning'],
        githubLink: 'https://github.com/rohitsai5246/Facial-Recognition-System',
        image: 'Interface showing facial recognition with bounding boxes on faces',
        imagePlaceholder: "https://images.unsplash.com/photo-1605578294888-8190bb98d9b4"
      },
      {
        id: 'handwritten-text-conversion',
        title: 'Handwritten Text to Digital Text',
        category: 'NLP & OCR',
        shortDescription: 'Converts handwritten text from images into editable digital text using NLP and OCR techniques.',
        detailedDescription: "This project focuses on Optical Character Recognition (OCR) and Natural Language Processing (NLP) to convert images of handwritten text into machine-readable digital text. It involves image preprocessing, character segmentation, feature extraction, and classification using machine learning or deep learning models (e.g., CRNN). Post-processing with NLP techniques can improve accuracy and context understanding. This demonstrates skills in both computer vision and NLP.",
        technologies: ['Python', 'OpenCV', 'Tesseract OCR', 'TensorFlow/Keras', 'NLP'],
        githubLink: 'https://github.com/rohitsai5246/Handwritten-Text-Conversion',
        image: 'Split view showing handwritten text image and its digital conversion',
        imagePlaceholder: "https://images.unsplash.com/photo-1517061493169-7cdec211afe4"
      },
      {
        id: 'random-password-generator',
        title: 'Random Password Generator',
        category: 'Utility Tool',
        shortDescription: 'A tool to generate strong, random passwords based on user-defined criteria.',
        detailedDescription: "A Python-based utility that generates secure, random passwords. Users can specify criteria such as password length, inclusion of uppercase/lowercase letters, numbers, and special characters. This project emphasizes understanding of string manipulation, random number generation, and basic security principles for creating robust passwords.",
        technologies: ['Python', 'Random module'],
        githubLink: 'https://github.com/rohitsai5246/Random-Password-Generator',
        image: 'Interface of a random password generator tool with options',
        imagePlaceholder: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb"
      },
      {
        id: 'speech-recognition-app',
        title: 'Speech Recognition Application',
        category: 'Voice Technology',
        shortDescription: 'An application that converts spoken language into written text.',
        detailedDescription: "This project utilizes speech recognition libraries (e.g., Google Speech Recognition API, SpeechRecognition library in Python) to convert audio input into text. It can take microphone input or process audio files. The application demonstrates an understanding of audio processing and working with speech-to-text APIs or models. Potential extensions include command recognition or voice-controlled interfaces.",
        technologies: ['Python', 'SpeechRecognition library', 'PyAudio'],
        githubLink: 'https://github.com/rohitsai5246/Speech-Recognition',
        image: 'Application interface showing transcribed text from speech input',
        imagePlaceholder: "https://images.unsplash.com/photo-1534536281715-e28d76689b4d"
      },
       {
        id: 'predictive-maintenance-iot',
        title: 'Predictive Maintenance for IoT Devices',
        category: 'Machine Learning & IoT',
        shortDescription: 'An ML model to predict failures in IoT devices based on sensor data, enabling proactive maintenance.',
        detailedDescription: "This project involves developing a machine learning model to predict potential failures in Industrial IoT (IIoT) devices. By analyzing real-time sensor data (e.g., temperature, vibration, pressure), the model identifies patterns indicative of impending issues. This allows for proactive maintenance scheduling, reducing downtime and operational costs. The solution uses time-series analysis and classification algorithms, potentially deployed on an edge device or cloud platform.",
        technologies: ['Python', 'Scikit-learn', 'TensorFlow/Keras', 'Pandas', 'MQTT', 'Cloud IoT Platform (e.g., AWS IoT)'],
        githubLink: '#', 
        image: 'Dashboard showing IoT sensor data and predictive maintenance alerts',
        imagePlaceholder: "https://images.unsplash.com/photo-1518770660439-4636190af475"
      },
      {
        id: 'customer-churn-prediction',
        title: 'Customer Churn Prediction Model',
        category: 'Data Science & Business Analytics',
        shortDescription: 'A data-driven model to identify customers at high risk of churning, helping businesses retain clients.',
        detailedDescription: "This project focuses on building a predictive model to identify customers likely to discontinue using a service (churn). Using historical customer data (demographics, usage patterns, support interactions), the model employs classification algorithms (e.g., Logistic Regression, Random Forest, Gradient Boosting) to predict churn probability. The insights help businesses implement targeted retention strategies. It involves data preprocessing, feature engineering, model training, and evaluation.",
        technologies: ['Python', 'Pandas', 'NumPy', 'Scikit-learn', 'Matplotlib/Seaborn', 'Jupyter Notebooks'],
        githubLink: '#',
        image: 'Chart illustrating customer churn analysis and prediction results',
        imagePlaceholder: "https://images.unsplash.com/photo-1556155092-490a1ba16284"
      }
    ]
  },
  contact: {
    title: "Let's Connect",
    subtitle: "I'm Seeking New Opportunities and Collaborations",
    intro: "I'm actively looking for job opportunities where I can contribute my skills in AI and Machine Learning. If you have a project in mind, a role to fill, or just want to discuss technology, feel free to reach out. You can also contact me via WhatsApp for a quicker response.",
    formPlaceholders: {
      name: "Your Name",
      email: "your.email@example.com",
      subject: "Job Opportunity / Project Inquiry",
      message: "Hello Rohit, I'm interested in discussing..."
    },
    contactDetails: [
      {
        icon: <MapPin className="h-6 w-6" />,
        title: 'Location',
        details: 'Guntur, Andhra Pradesh, India'
      },
      {
        icon: <Mail className="h-6 w-6" />,
        title: 'Email',
        details: 'rohitsaikamepalli@gmail.com'
      },
      {
        icon: <Phone className="h-6 w-6" />,
        title: 'Phone / WhatsApp',
        details: '+91 8008160135'
      }
    ]
  },
  footer: {
    copyrightText: "Kamepalli Rohit Sai. All rights reserved."
  }
};
