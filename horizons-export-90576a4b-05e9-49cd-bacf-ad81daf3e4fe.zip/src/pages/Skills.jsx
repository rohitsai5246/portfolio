
import React from 'react';
import { motion } from 'framer-motion';
import SectionHeading from '@/components/SectionHeading';
import PageTransition from '@/components/PageTransition';
import { portfolioData } from '@/data/portfolioData';

const Skills = () => {
  const { title, subtitle, technicalSkills, softSkills, tools } = portfolioData.skills;

  const SkillBar = ({ skill, index }) => (
    <motion.div 
      className="mb-6"
      initial={{ opacity: 0, x: -50 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <div className="flex justify-between mb-1">
        <span className="font-medium text-sm">{skill.name}</span>
        <span className="text-primary text-sm">{skill.percentage}%</span>
      </div>
      <div className="skill-bar">
        <motion.div 
          className="skill-progress"
          initial={{ width: 0 }}
          whileInView={{ width: `${skill.percentage}%` }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 + index * 0.1, ease: "easeOut" }}
        />
      </div>
    </motion.div>
  );

  const SoftSkillCard = ({ skill, index }) => (
    <motion.div
      className="p-4 rounded-lg border border-border bg-card flex items-start gap-3"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <div className="flex-shrink-0 w-8 h-8 rounded-full gradient-bg text-white flex items-center justify-center mt-1">
        {skill.icon}
      </div>
      <div>
        <h4 className="font-semibold text-sm">{skill.name}</h4>
        <p className="text-xs text-muted-foreground">{skill.description}</p>
      </div>
    </motion.div>
  );


  return (
    <PageTransition>
      <section className="section-padding">
        <div className="container px-4 md:px-6">
          <SectionHeading 
            title={title} 
            subtitle={subtitle} 
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <motion.h3 
                className="text-2xl font-semibold mb-6 flex items-center text-gradient"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                Technical Skills
              </motion.h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8">
                {technicalSkills.map((skill, index) => (
                  <SkillBar key={index} skill={skill} index={index} />
                ))}
              </div>
            </div>
            
            <div>
              <motion.h3 
                className="text-2xl font-semibold mb-6 flex items-center text-gradient"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                Soft Skills
              </motion.h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {softSkills.map((skill, index) => (
                  <SoftSkillCard key={index} skill={skill} index={index} />
                ))}
              </div>
            </div>
          </div>
          
          <motion.div 
            className="mt-12 p-6 md:p-8 rounded-xl border border-border bg-card shadow-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-xl md:text-2xl font-semibold mb-6 text-center text-gradient">Tools & Technologies I Use</h3>
            <div className="flex flex-wrap justify-center gap-3 md:gap-4">
              {tools.map((tool, index) => (
                <motion.span 
                  key={index}
                  className="px-3 py-1.5 md:px-4 md:py-2 rounded-full bg-primary/10 text-primary text-xs md:text-sm font-medium"
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                >
                  {tool}
                </motion.span>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Skills;
