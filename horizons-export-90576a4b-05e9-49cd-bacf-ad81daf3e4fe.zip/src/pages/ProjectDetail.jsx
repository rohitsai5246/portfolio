
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { portfolioData } from '@/data/portfolioData';
import PageTransition from '@/components/PageTransition';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Github, ExternalLink } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';

const ProjectDetail = () => {
  const { projectId } = useParams();
  const project = portfolioData.projects.items.find(p => p.id === projectId);

  if (!project) {
    return (
      <PageTransition>
        <div className="container px-4 md:px-6 section-padding text-center">
          <h1 className="text-3xl font-bold mb-4">Project Not Found</h1>
          <p className="text-muted-foreground mb-8">Sorry, we couldn't find the project you're looking for.</p>
          <Button asChild>
            <Link to="/projects">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Projects
            </Link>
          </Button>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <section className="section-padding">
        <div className="container px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <Button variant="outline" asChild className="mb-8">
              <Link to="/projects">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Projects
              </Link>
            </Button>
            <SectionHeading title={project.title} subtitle={project.category} />
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative aspect-video rounded-xl overflow-hidden shadow-2xl border border-border mb-8">
                <img  alt={project.title} class="w-full h-full object-cover" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
              </div>
              <h2 className="text-2xl font-semibold mb-4 text-gradient">Project Overview</h2>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{project.detailedDescription}</p>
            </motion.div>

            <motion.div
              className="lg:col-span-1"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="sticky top-24 p-6 rounded-xl border border-border bg-card shadow-lg">
                <h3 className="text-xl font-semibold mb-4">Project Info</h3>
                <div className="space-y-3 mb-6">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Category</h4>
                    <p className="text-foreground">{project.category}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">Technologies Used</h4>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {project.technologies.map((tech, index) => (
                        <span key={index} className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  {project.demoLink && project.demoLink !== "#" && (
                    <Button asChild className="w-full gradient-bg text-white hover:opacity-90">
                      <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="mr-2 h-4 w-4" /> View Live Demo
                      </a>
                    </Button>
                  )}
                  {project.githubLink && project.githubLink !== "#" && (
                    <Button variant="outline" asChild className="w-full">
                      <a href={project.githubLink} target="_blank" rel="noopener noreferrer">
                        <Github className="mr-2 h-4 w-4" /> View on GitHub
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default ProjectDetail;
