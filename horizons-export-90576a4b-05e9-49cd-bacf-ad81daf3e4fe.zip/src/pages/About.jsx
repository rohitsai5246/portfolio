
import React from 'react';
import { motion } from 'framer-motion';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SectionHeading from '@/components/SectionHeading';
import PageTransition from '@/components/PageTransition';
import { portfolioData } from '@/data/portfolioData';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const About = () => {
  const { title, subtitle, bio, details } = portfolioData.about;
  const { cvLink, profileImage, name } = portfolioData.personalInfo;

  return (
    <PageTransition>
      <section className="section-padding">
        <div className="container px-4 md:px-6">
          <SectionHeading 
            title={title} 
            subtitle={subtitle} 
          />
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="md:col-span-2 relative flex justify-center"
            >
              <div className="relative z-10">
                <Avatar className="w-60 h-60 md:w-72 md:h-72 rounded-lg border-4 border-primary/30 shadow-xl">
                  <AvatarImage src={profileImage} alt={name} />
                  <AvatarFallback>{name.substring(0,2).toUpperCase()}</AvatarFallback>
                </Avatar>
              </div>
              <div className="absolute -bottom-4 -right-4 md:-bottom-6 md:-right-6 w-48 h-48 md:w-64 md:h-64 bg-primary/10 rounded-lg -z-10 transform rotate-12"></div>
               <div className="absolute -top-4 -left-4 md:-top-6 md:-left-6 w-48 h-48 md:w-64 md:h-64 bg-secondary rounded-lg -z-10 transform -rotate-12"></div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="md:col-span-3"
            >
              <h3 className="text-2xl md:text-3xl font-bold mb-6 text-gradient">Who am I?</h3>
              {bio.map((paragraph, index) => (
                <p key={index} className="text-muted-foreground mb-6 text-base md:text-lg">
                  {paragraph}
                </p>
              ))}
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 mb-8">
                {details.map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{item.label}</p>
                      <p className="text-sm text-muted-foreground">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              {cvLink && cvLink !== "#" && (
                <Button asChild size="lg" className="rounded-full gradient-bg text-white hover:opacity-90 transition-opacity">
                  <a href={cvLink} target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-5 w-5" /> Download CV
                  </a>
                </Button>
              )}
            </motion.div>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default About;
