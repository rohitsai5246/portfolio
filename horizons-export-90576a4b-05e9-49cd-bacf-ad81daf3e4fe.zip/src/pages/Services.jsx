
import React from 'react';
import { motion } from 'framer-motion';
import SectionHeading from '@/components/SectionHeading';
import PageTransition from '@/components/PageTransition';
import { portfolioData } from '@/data/portfolioData';

const Services = () => {
  const { title, subtitle, items } = portfolioData.services;

  return (
    <PageTransition>
      <section className="section-padding">
        <div className="container px-4 md:px-6">
          <SectionHeading 
            title={title} 
            subtitle={subtitle} 
          />
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((service, index) => (
              <motion.div 
                key={index}
                className="service-card"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="w-16 h-16 rounded-lg gradient-bg flex items-center justify-center text-white mb-4">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-muted-foreground">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Services;
