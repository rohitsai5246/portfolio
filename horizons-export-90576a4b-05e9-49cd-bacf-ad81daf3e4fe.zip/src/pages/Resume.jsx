
import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, GraduationCap } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import SectionHeading from '@/components/SectionHeading';
import PageTransition from '@/components/PageTransition';
import { portfolioData } from '@/data/portfolioData';

const Resume = () => {
  const { title, subtitle, education, experience } = portfolioData.resume;

  const TimelineItem = ({ item, icon, index }) => (
    <motion.div 
      className="relative pl-10 pb-10 last:pb-0"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <div className="absolute left-0 top-0 bottom-0 w-px bg-border"></div>
      <div className="absolute left-0 top-0 -translate-x-1/2 w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
        {icon}
      </div>
      <div className="p-4 rounded-lg border border-border bg-card">
        <div className="flex flex-wrap justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">{item.position || item.degree}</h3>
          <span className="text-sm text-muted-foreground">{item.period}</span>
        </div>
        <p className="text-primary mb-2">{item.company || item.institution}</p>
        <p className="text-muted-foreground">{item.description}</p>
      </div>
    </motion.div>
  );

  return (
    <PageTransition>
      <section className="section-padding">
        <div className="container px-4 md:px-6">
          <SectionHeading 
            title={title} 
            subtitle={subtitle} 
          />
          
          <Tabs defaultValue="experience" className="w-full max-w-3xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="experience" className="text-base">
                <Briefcase className="mr-2 h-4 w-4" /> Experience
              </TabsTrigger>
              <TabsTrigger value="education" className="text-base">
                <GraduationCap className="mr-2 h-4 w-4" /> Education
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="experience" className="mt-0">
              <div className="space-y-4">
                {experience.map((item, index) => (
                  <TimelineItem 
                    key={index} 
                    item={item} 
                    icon={item.icon} 
                    index={index}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="education" className="mt-0">
              <div className="space-y-4">
                {education.map((item, index) => (
                  <TimelineItem 
                    key={index} 
                    item={item} 
                    icon={item.icon} 
                    index={index}
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </PageTransition>
  );
};

export default Resume;
