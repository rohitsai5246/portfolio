
import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SectionHeading from '@/components/SectionHeading';
import PageTransition from '@/components/PageTransition';
import { portfolioData } from '@/data/portfolioData';
import { Link } from 'react-router-dom';

const Projects = () => {
  const { title, subtitle, items } = portfolioData.projects;

  return (
    <PageTransition>
      <section className="section-padding">
        <div className="container px-4 md:px-6">
          <SectionHeading 
            title={title} 
            subtitle={subtitle} 
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {items.map((project, index) => (
              <motion.div 
                key={project.id || index}
                className="project-card flex flex-col"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="relative overflow-hidden aspect-[16/10] rounded-t-xl">
                  <img  alt={project.title} class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                     <span className="text-xs bg-primary/80 text-primary-foreground px-2 py-1 rounded font-medium">{project.category}</span>
                  </div>
                </div>
                
                <div className="p-5 bg-card rounded-b-xl border-x border-b border-border flex-grow flex flex-col">
                  <h3 className="text-xl font-semibold mb-2 text-foreground">{project.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-grow">{project.shortDescription}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.slice(0, 3).map((tech, techIndex) => (
                      <span key={techIndex} className="text-xs px-2 py-1 bg-secondary text-secondary-foreground rounded-full">
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 3 && (
                       <span className="text-xs px-2 py-1 bg-secondary text-secondary-foreground rounded-full">
                        +{project.technologies.length - 3} more
                      </span>
                    )}
                  </div>

                  <div className="mt-auto flex gap-3">
                    <Button size="sm" asChild className="flex-1 gradient-bg text-white hover:opacity-90">
                      <Link to={`/project/${project.id}`}>
                        View Details <ArrowRight className="h-4 w-4 ml-1" />
                      </Link>
                    </Button>
                    {project.githubLink && project.githubLink !== "#" && (
                      <Button size="icon" variant="outline" asChild>
                        <a href={project.githubLink} target="_blank" rel="noopener noreferrer" aria-label="GitHub Repository">
                          <Github className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

export default Projects;
